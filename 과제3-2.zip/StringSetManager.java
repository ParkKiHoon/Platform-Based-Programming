import java.util.Scanner;

import static javax.swing.UIManager.getString;

enum StringCommand {ADD,REMOVE,CLEAN,QUIT,INVALID}
public class StringSetManager {
    static int index=0;
    public static void main(String[] args){
        final Scanner scanner=new Scanner(System.in);
        String[] stringSet=new String[100];
        while (true){
            final StringCommand command = getCommand(scanner.next());
            if(command==StringCommand.QUIT){
                System.out.println("BYE!");break;
            }
            switch (command){
                case ADD: {
                    final String str = scanner.next();
                    add(stringSet,str);
                    break;
                }
                case REMOVE: {
                    final String str = scanner.next();
                    remove(stringSet,str);
                    break;
                }
                case CLEAN:{
                    clear(stringSet);
                    break;
                }
                default: {
                    System.out.println("Unknown Command!");;
                    break;
                }
            }print(stringSet);
        }
    }
    private static StringCommand getCommand(final String scanner){
        switch (scanner.toUpperCase()){
            case "ADD":
                return StringCommand.ADD;
            case "REMOVE":
                return StringCommand.REMOVE;
            case "CLEAN":
                return StringCommand.CLEAN;
            case "QUIT":
                return StringCommand.QUIT;
            default:
                return StringCommand.INVALID;
        }
    }

    private static void add(String[] strings,String str){
        for(int i=0;i<index;i++){
            if(strings[i].equals(str))
                return;
        }
        strings[index] = str;
        index++;
    }

    private static void remove(String[] strings,String str){
        for(int i=0; i< index;i++){
            if(strings[i].equals(str)){
                for(int j=i;j<index;j++){
                    strings[j]=strings[j+1];
                }
                strings[index]=null;
                index--;
            }
        }
    }

    private static void clear(String[] strings){
        for(int i=0;i<index;i++){
            strings[i]=null;
        }
        index=0;
    }




    private static void print(String[] strings){
        System.out.printf("Element Size: " + index +", Values = [");
        for(int i=0;i< index;i++){
            System.out.printf(strings[i]);
            if(i!=index-1&&index!=0){
                System.out.printf(", ");
            }
        }
        System.out.println("]");
    }
}
