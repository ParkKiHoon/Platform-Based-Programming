package uk.epl.player;

public class Midfielder extends Player{
    public Midfielder(String name, int jerseyNumber, int speed, int stamina, int passing) {
        super(name, jerseyNumber, speed, stamina, passing+10);
        position=new Position(0,0);
    }
}
