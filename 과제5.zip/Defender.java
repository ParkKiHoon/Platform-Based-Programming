package uk.epl.player;

public class Defender extends Player  {
    public Defender(String name, int jerseyNumber, int speed, int stamina, int passing) {
        super(name, jerseyNumber, speed, stamina+10, passing);
        position=new Position(0,0);
    }


}
