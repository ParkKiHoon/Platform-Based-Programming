package uk.epl.player;

import javax.swing.*;
import java.text.DecimalFormat;
import java.util.Arrays;

public abstract class Player {
    private String name;
    private int jerseyNumber;

    public Player(String name, int jerseyNumber, int speed, int stamina, int passing) {
        this.name = name;
        this.jerseyNumber = jerseyNumber;
        this.abilities[0] = speed;
        this.abilities[1] = stamina;
        this.abilities[2] = passing;
    }
    private int[] abilities = new int[3];

    final int SPEED= 0; final int STAMINA = 1; final int PASSING = 2;

    Position position;


    public  class Position{
        public int x;
        public int y;

        public Position(int x, int y) {
            this.x=x;
            this.y=y;
        }
    }

    public void setPosition(int x,int y) {
        this.position.x = x;
        this.position.y = y;
    }

    public Position getPosition(){
        return new Position(position.x,position.y);
    }

    public void moveUp(){
        float move_delta=getMoveDelta();
        position.y=(int)(position.y-move_delta);
        decreaseStamina();
    }

    public void moveDown(){
        float move_delta=getMoveDelta();
        position.y=(int)(position.y+move_delta);
        decreaseStamina();
    }

    public void moveLeft(){
        float move_delta=getMoveDelta();
        position.x=(int)(position.x-move_delta);
        decreaseStamina();
    }

    public void moveRight(){
        float move_delta=getMoveDelta();
        position.x=(int)(position.x+move_delta);
        decreaseStamina();
    }


    private void decreaseStamina(){
        abilities[STAMINA]=(int)(abilities[STAMINA]-2);
    }

    private float getMoveDelta(){
        return 1+getSpeed()/100*getStamina()/100;
    }

    protected float getSpeed(){
        return (float) abilities[SPEED];
    }
    protected float getStamina(){
        return (float) abilities[STAMINA];
    }

    public int getJerseyNumber(){
        return jerseyNumber;
    }

    @Override
    public String toString() {
        return "Player Name='"+name+", JerseyNumber="+jerseyNumber+" Position ("
                +position.x+" , "+position.y+") "+getClass().getSimpleName()+
                " SPEED="+abilities[0]+".0, , STAMINA="+abilities[1]
                +".0, , PASSING="+abilities[2]+".0";
    }
}
