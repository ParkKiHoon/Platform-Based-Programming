package uk.epl.game;

import uk.epl.player.Player;
import java.util.ArrayList;
import java.util.List;

public class Field {
    private List<Player> players=new ArrayList<>();

    public void moveUp(int choosePlayer) {
        for(int i=0;i<players.size();i++){
            if(players.get(i).getJerseyNumber()==choosePlayer){
                players.get(i).moveUp();
            }
        }
    }

    public void moveDown(int choosePlayer) {
        for(int i=0;i<players.size();i++){
            if(players.get(i).getJerseyNumber()==choosePlayer){
                players.get(i).moveDown();
            }
        }
    }

    public void moveLeft(int choosePlayer) {
        for(int i=0;i<players.size();i++){
            if(players.get(i).getJerseyNumber()==choosePlayer){
                players.get(i).moveLeft();
            }
        }
    }

    public void moveRight(int choosePlayer) {
        for(int i=0;i<players.size();i++){
            if(players.get(i).getJerseyNumber()==choosePlayer){
                players.get(i).moveRight();
            }
        }
    }

    public void add(Player player){
        players.add(player);
    }

    public void start() {
        for(int i=0;i<players.size();i++) {
            if(players.get(i).getClass().getSimpleName().equals("Forward")){
                players.get(i).setPosition(34,25);
            }
            else if(players.get(i).getClass().getSimpleName().equals("Midfielder")){
                players.get(i).setPosition(34,50);
            }
            else if(players.get(i).getClass().getSimpleName().equals("Defender")){
                players.get(i).setPosition(34,75);
            }
        }
    }

    public void info() {
        for(int i=0;i<players.size();i++){
            System.out.println(players.get(i));
        }
    }

    public void stop() {
        for(int i=0;i<players.size();i++) {
             players.get(i).setPosition(0,0);
        }
    }
}
