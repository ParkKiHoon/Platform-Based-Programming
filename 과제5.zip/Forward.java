package uk.epl.player;

public class Forward extends Player{
    public Forward(String name, int jerseyNumber, int speed, int stamina, int passing) {
        super(name, jerseyNumber, speed+10, stamina, passing);
        position=new Position(0,0);
    }

}
