package edu.pnu.collection;

import edu.pnu.admin.Student;

import java.util.Arrays;
import java.util.Objects;

public class GenericList<T> {
    private static final int DEFAULT_SIZE=10;
    private Object[] data;
    private int size=0;

    public GenericList() {
        this.data =new Object[DEFAULT_SIZE];
    }

    public void add(Student student){
        this.data[size++]=student;
    }

    public void remove(){
        this.size=0;
    }

    public int getSize(){return this.size;}


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GenericList<?> that = (GenericList<?>) o;
        return size == that.size && Arrays.equals(data, that.data);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(size);
        result = 31 * result + Arrays.hashCode(data);
        return result;
    }

    public void setSize(int size){this.size+=size;}

    public T getData(int index){
        return (T)data[index];
    }
}
