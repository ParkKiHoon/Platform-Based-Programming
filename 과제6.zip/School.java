package edu.pnu.admin;
import edu.pnu.collection.GenericList;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Objects;

public class School {
    private String name;
    private int limit;
    private GenericList<Student> students=new GenericList<Student>();

    public School(String name) {//no limit School constructor
        this.name=name;
    }

    public School(String name,int limit) {//limit School constructor
        this.name=name;
    }

    public void addStudent(Student student){
        students.add(student);
    }

    public void removeAllStudent(){
        students.remove();
    }

    public Student findStudent(String studentName, int schoolYear){
        for(int i=0;i<students.getSize();i++){
            if(students.getData(i).toString().equals("[" + studentName + ", " + schoolYear +"학년]"))
                return students.getData(i);
        }
        return null;
    }

    public String toString(){
        String msg = "School Name: "+name+" Student Count: " + students.getSize()+ "\n";
        for (int i=0;i< students.getSize();i++){
            msg+="\t"+students.getData(i)+"\n";
        }
        return msg;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        School school = (School) o;
        return limit == school.limit && Objects.equals(name, school.name) && Objects.equals(students, school.students);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, limit, students);
    }
}
