import java.util.Scanner;

public class FactorialMain {
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        int input= scanner.nextInt();
        scanner.close();
        System.out.println("Enter a number: ");
        for(int i=1;i<=input;i++){
            System.out.println("Factorial of "+i+" = "+getFactorial(i));
        }
    }
    private static long getFactorial(int input){
        if(input<=1)
            return input;
        else
            return getFactorial(input-1)*input;
    }
}
