import java.util.Arrays;
import java.util.Scanner;

public class ArrayEnum {
    enum Command{ADD,LIST,SUM,MAX,MIN,QUIT,INVALID};
    public static void main(String[] args){
        int[] values=new int[100];
        final Scanner scanner=new Scanner(System.in);
        int index=0;

        while(true){
            final Command command = getCommand(scanner.next());
            if(command==Command.QUIT){
                System.out.println("Bye!");
                break;
            }
            switch (command){
                case ADD:
                    final int newValue=scanner.nextInt();
                    values[index]=newValue;
                    index++;
                    break;
                case LIST:
                    printList(values,index);
                    break;
                case SUM:
                    System.out.println(getSum(values,index));
                    break;
                case MAX:
                    System.out.println(getMax(values,index));
                    break;
                case MIN:
                    System.out.println(getMin(values,index));
                    break;
                case INVALID:
                    System.out.println("Invalid Command");
                    break;
            }
        }
        scanner.close();
    }

    private static Command getCommand(final String scanner){
        switch (scanner.toUpperCase()){
            case "ADD":
                return Command.ADD;
            case "LIST":
                return Command.LIST;
            case "SUM":
                return Command.SUM;
            case "MAX":
                return Command.MAX;
            case "MIN":
                return Command.MIN;
            case "QUIT":
                return Command.QUIT;
            default:
                return Command.INVALID;
        }
    }

    private static void printList(int[] values,int index){
        for(int i=0;i<index;i++){
            System.out.printf(values[i] + " ");
        }
        System.out.println();
    }

    private static int getSum(int[] values,int index){
        int sum=0;
        for(int i=0;i<index;i++){
            sum+=values[i];
        }
        return sum;
    }

    private static int getMax(int[] values,int index){
        int temp=0;
        for(int i=0;i<index;i++){
            if(values[i]>temp)
                temp=values[i];
        }
        return temp;
    }

    private static int getMin(int[] values,int index){
        int temp=2147483647;
        for(int i=0;i<index;i++){
            if(values[i]<temp)
                temp=values[i];
        }
        return temp;
    }
}
